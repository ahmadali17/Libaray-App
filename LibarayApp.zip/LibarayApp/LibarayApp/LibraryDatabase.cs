﻿using System;
using System.Collections.Generic;

namespace LibarayApp
{
    public class LibraryDatabase
    {
        public Queue<Book> ListOfBooks = new Queue<Book>();

        public LibraryDatabase()
        {
        }

        //set
        //get

        //add
        //delete
        //display
    }
}
