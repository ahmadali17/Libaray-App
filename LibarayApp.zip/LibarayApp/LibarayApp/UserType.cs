﻿using System;
namespace LibarayApp
{
    public enum UserType
    {
        staff, customer
    }
}
